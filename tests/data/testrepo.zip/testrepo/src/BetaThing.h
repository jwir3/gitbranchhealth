#ifndef __BETATHING_H__
#define __BETATHING_H__

#include "Thing.h"
#include <string>

class BetaThing : public Thing {

  public:
    BetaThing();

    void printName();

  private:
    std::string mGreeting;
};

#endif
