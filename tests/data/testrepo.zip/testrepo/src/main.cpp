#include <iostream>
#include "Thing.h"

using namespace std;

int main(int argc, char** argv) {
  cout << "Hello World" << endl;

  Thing* thing = new Thing("Computer");
  thing->printName();
  delete thing;
}
