#include "Thing.h"
#include <iostream>

using namespace std;

Thing::Thing(string aName) {
  mName = aName;
}

Thing::~Thing() {
}

void Thing::printName() {
  cout << "Thing Name: " << mName << endl;
}
