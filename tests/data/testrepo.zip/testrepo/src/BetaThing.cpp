#include "BetaThing.h"
#include <iostream>

using namespace std;

BetaThing::BetaThing() : Thing("Beta") {
  mGreeting = "Hello";
}

void BetaThing::printName() {
  cout << mGreeting << ", this is " << mName;
}
